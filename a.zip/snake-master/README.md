# Snake
A simple snake game built with HTML and JavaScript

Video tutorial: https://youtu.be/oY-WEIXNIvI
